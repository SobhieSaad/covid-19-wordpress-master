<script>
    var symptoma_mode = 'CORONA';
    var symptoma_integration = 'banner';
    var symptoma_banner_title = '<?=_e("COVID-19", SYMPTOMA_COVID19_SLUG)?>';
    var symptoma_banner_subtitle = '<?=_e("Start Test", SYMPTOMA_COVID19_SLUG)?>';
    var symptoma_banner_link_text = '<?=_e("Info", SYMPTOMA_COVID19_SLUG)?>';
    var symptoma_banner_link_url = '<?=_e("https://www.symptoma.com/covid-19", SYMPTOMA_COVID19_SLUG)?>';
</script>
<script id="symptoma-integration" type="text/javascript" src="https://www.symptoma.net/en/embed.js"></script>